<?php
/* Ohjelma tulostaa yhden jutun kannasta */

$jid="";
if(isset($_GET["jid"])) $jid=$_GET['jid'];

$sql="SELECT * FROM kirjat INNER JOIN opiskelijat ON opiskelijat.opiskelijaid = kirjat.opiskelijaid WHERE kirjaid=?";

require "./tietokanta/yhteys.php";
$kysely=$yhteys->prepare($sql);
$kysely->execute(array($jid));

$rivi = $kysely->fetchAll(PDO::FETCH_ASSOC);

if(empty($rivi)) echo "Kirjaa ei löydy";

else
{
	
$nimi=$rivi[0]["nimi"];
$tekija=$rivi[0]["tekija"];
$kuvaus=$rivi[0]["kuvaus"];
$kpl=$rivi[0]["hinta"];
$kuva=$rivi[0]["kuva"];
$sposti=$rivi[0]["sposti"];

echo "<title>Kirpputori: " .$nimi."</title>";
echo "<h3>".$nimi."</h3>";
echo "<p>Tekijä: ".$tekija."</p>";
echo "<article>Kuvaus: ".$kuvaus."</article>";
echo "<p>Hinta: ".$kpl."€</p>";
echo "<p>Ota yhteyttä: ".$sposti."</p>";
echo "<p><img src='sisalto/kuvat/".$kuva."' width='150' height='150' draggable='false' />";

echo "<br><a href=\"index.php?sivu=index\"><< Palaa etusivulle </a>";
}
?>

