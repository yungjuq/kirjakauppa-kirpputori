<!DOCTYPE html>
<html>
<head>
	<title>Kirpputori: Ylläpito</title>
</head>
<body>
<form action="admin.php?sivu=admin" method="POST">
<h4>Hae tiettyä kirjaa</h4>
<label for="search"></label>
<input type="text" name="haku" maxlength="50" placeholder="Kirjoita kenttään kirjan nimi" style="width:80%; border-radius: 0px;" />
<button type="submit" class="btn btn-primary btn-sm" style="border-radius: 0px;">Hae kirja</button>
</form>
<?php

$kid="";
if(isset($_SESSION["opiskelijaid"])) $kid=$_SESSION["opiskelijaid"];


if (isset($_POST["haku"])) {
	// hakukentästä löytyi tekstiä
	$haku = $_POST["haku"];
	echo "<p style=\"text-align: center\">Haettu " . $haku . "</p>";
	echo "<hr class=\"haku\">";
	$sql ="SELECT * FROM kirjat WHERE opiskelijaid='$kid' AND nimi LIKE '%" . $haku . "% ORDER BY lisayspvm desc";
	// $sql="SELECT * FROM kirjat WHERE nimi LIKE '%" . $haku . "%' ORDER BY lisayspvm desc";
}
else {
	echo "<p style=\"text-align: center\"></p>";	
	echo "<hr class=\"haku\">";
	$sql ="SELECT * FROM kirjat WHERE opiskelijaid='$kid' ORDER BY lisayspvm desc";
}


echo "<h1>Omat ilmoitukseni</h1>";


require "./tietokanta/yhteys.php";
$kysely=$yhteys->query($sql);

$rivit = $kysely->rowCount();
$vastaus = $kysely->fetchAll(PDO::FETCH_ASSOC); 

for($i=0;$i<$rivit;$i++)
{
	$kirjaid=$vastaus[$i]["kirjaid"];
	$lisayspvm=$vastaus[$i]["lisayspvm"];
	$nimi=$vastaus[$i]["nimi"];
	$kuva=$vastaus[$i]["kuva"];
	$hinta=$vastaus[$i]["hinta"];
	$kuvaus=$vastaus[$i]["kuvaus"];
	$kid=$vastaus[$i]["opiskelijaid"];
	$kirjoittaja=kayttajan_nimi($kid,$yhteys);
	
	echo "<div class=\"row\">";
    echo "<div class=\"col-md-4\">";
      echo "<div class=\"thumbnail\">";
			echo "<h4 style=\"text-align: center;\">".$nimi."</a></h4>";
			echo "<img src='sisalto/kuvat/".$kuva."' width='150' height='150' draggable='false'/>";
			echo "<div class=\"caption\">";
            echo "<p>$kuvaus</p>";
			echo "<a href=\"admin.php?sivu=muokkaa_kirjaa&kirjaid=$kirjaid&mode=muokkaa\" class=\"muokkaajuttu\">Muokkaa juttua </a>\n";
			echo "<a href=\"admin.php?sivu=muokkaa_kirjaa&kirjaid=$kirjaid&mode=poista\" class=\"poistajuttu\">Poista juttu</a>\n";
          echo "</div>";
        echo "</a>";
      echo "</div>";
    echo "</div>";
	echo "</div>";
	
	
	

} ?>

