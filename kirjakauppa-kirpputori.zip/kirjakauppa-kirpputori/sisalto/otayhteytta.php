<!DOCTYPE html>
<html>
<head>
	<title>Kirjakauppa: Ota yhteyttä</title>
</head>
<body>
<?php
if(isset($_POST['email'])) {
 
    $email_to = "yanar.kendo@gmail.com";
    $email_subject = "Kirpputori";
 
    function died($error) {
        echo "Virhe viestiä lähettäessä, yritä uudelleen.";
        die();
    }
 
 
    if(!isset($_POST['etunimi']) ||
        !isset($_POST['sukunimi']) ||
        !isset($_POST['email']) ||
        !isset($_POST['viesti'])) {
        died('Virhe viestin lähettämisessä, yritä pian uudelleen.');       
    }
 
     
 
    $etunimi = $_POST['etunimi'];
    $sukunimi = $_POST['sukunimi'];
    $email_from = $_POST['email'];
    $viesti = $_POST['viesti']; 
 
    $error_message = "";
    $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
 
  if(!preg_match($email_exp,$email_from)) {
    $error_message .= 'Antamasi sähköpostiosoite on virheellinen';
  }
 
    $string_exp = "/^[A-Za-z .'-]+$/";
 
  if(!preg_match($string_exp,$etunimi)) {
    $error_message .= '';
  }
 
  if(!preg_match($string_exp,$sukunimi)) {
    $error_message .= '<br />';
  }
 
  if(strlen($viesti) < 2) {
    $error_message .= '';
  }
 
  if(strlen($error_message) > 0) {
    died($error_message);
  }
 
    $email_message = "";
 
     
    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }
 
     
    $email_message .= "".clean_string($viesti)."\n";

$headers = 'From: '.$email_from."\r\n".
'Reply-To: '.$email_from."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject, $email_message, $headers);  
?>
 
 
Viesti lähetetty onnistuneesti
 
<?php
 
}
?>
<h3 style="text-align: center;">Ota yhteyttä</h3>
<div>
<form name="contactform" method="post" action="index.php?sivu=otayhteytta">
    <label for="fname"></label>
    <input type="text" name="nimi" placeholder="Etunimi *" value="<?php if(isset($nimi)) echo $nimi?>">

    <label for="lname"></label>
    <input type="text" name="tekija" placeholder="Sukunimi *" value="<?php if(isset($tekija)) echo $tekija?>">
	
	<label for="lname"></label>
    <input type="text" name="email" placeholder="Sähköpostiosoite *" value="<?php if(isset($hinta)) echo $hinta?>">
	
	<label for="lname"></label>
    <textarea name="viesti" placeholder="Viesti *" maxlength="1000"></textarea>
	
	<input type="submit" value="Lähetä">
</form>
</div>


