<!DOCTYPE html>
<html>
<head>
	<title>Kirpputori: Kirjaudu</title>
</head>
<body>
<?php require "./tietokanta/yhteys.php"; ?>
<?php 
if(isset($_GET["puuttuu"])) echo "<div class=\"alert alert-danger\" style=\"text-align: center;\">Täytä molemmat kentät!</div>";
if(isset($_GET["vaarin"])) echo "<div class=\"alert alert-danger\" style=\"text-align: center;\">Käyttäjätunnus ja salasana eivät vastaa toisiaan</div>";
?>
<h3 style="text-align: center;">Kirjaudu</h3>
<div>
<form action="./tarkista_kirjautuminen.php" method="post">
	<label for="lname"></label>
	<input type="email" name="ktunnus" placeholder="Sähköpostiosoite"><br>
    <label for="fname"></label>
    <input type="password" name="salasana" placeholder="Salasana">

	<input type="submit" value="Kirjaudu">
</form>
</div>