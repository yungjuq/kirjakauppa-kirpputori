<?php
/******************
Taulun rakenne
jid int(6) auto_increment (on siis autonumber tai laskuri-tyyppinen), pääavain
otsikko varchar(100)
kpl text
poistamispvm date NOT NULL
lisayspvm date
kid int(6)
**********************/
require "./tietokanta/yhteys.php";
if(isset($_GET["kirjaid"])) $kirjaid=$_GET["kirjaid"];
else $kirjaid="";

if(isset($_GET["mode"])) $mode=$_GET["mode"];
else $mode="muokkaa";
if($mode=="poista")
{

$sql="DELETE FROM kirjat WHERE kirjaid=?"; $kysely=$yhteys->prepare($sql); $kysely->execute(array($kirjaid));
header("Location:admin.php");

}

if($mode=="muokkaa")
{

if(!empty($_POST["nimi"]) && !empty($_POST["hinta"]))
{


$lisayspvm = date('Y-m-j');
$nimi = $_POST['nimi'];
$nimi = putsaa($nimi);
$tekija = $_POST['tekija'];
$tekija = putsaa($tekija);
$kuvaus = $_POST['kuvaus'];
$kuvaus = putsaa($kuvaus);
$hinta = $_POST['hinta'];
$hinta = putsaa($hinta);
$opiskelijaid = $_SESSION['opiskelijaid'];

// jos kuvaa ei oltu valittu
$fileToUpload = "";
// jos kuva on valittu niin käytetään sitä:
if (isset($_FILES["fileToUpload"]["name"])) {
	$fileToUpload = basename($_FILES["fileToUpload"]["name"]);
	$fileToUpload = putsaa($fileToUpload);	
}

if(isset($_POST['poistamispvm'])) $poistamispvm=$_POST['poistamispvm'];
else 
{

$poistamispvm = strtotime($lisayspvm) + (14 * 24 * 60 * 60);//14 päivää sekunteina
$poistamispvm = date('Y-m-j', $poistamispvm);

}

$kirjaid=$_POST["kirjaid"];


// kuvan lataaminen
if ($fileToUpload != "") {
	$target_dir = "sisalto/kuvat/";
	$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
	$uploadOk = 1;
	$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
	// Check if image file is a actual image or fake image
	if(isset($_POST["submit"])) {
			$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
			if($check !== false) {
				echo "File is an image - " . $check["mime"] . ".";
				$uploadOk = 1;
			} else {
				echo "File is not an image.";
				$uploadOk = 0;
			}
		}
		// Check if file already exists
		if (file_exists($target_file)) {
			echo "Sorry, file already exists.";
			$uploadOk = 0;
		}
	// Check file size
	if ($_FILES["fileToUpload"]["size"] > 500000) {
			echo "Sorry, your file is too large.";
			$uploadOk = 0;
		}
	// Allow certain file formats
	if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
	&& $imageFileType != "gif" ) {
			echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			$uploadOk = 0;
	}
	// Check if $uploadOk is set to 0 by an error
	if ($uploadOk == 0) {
			echo "Sorry, your file was not uploaded.";
	// if everything is ok, try to upload file
	} else {
		if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
			echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
			} else {
				echo "Sorry, there was an error uploading your file.";
			}
		}	
}

if ($fileToUpload != "") {
	$sql = "UPDATE kirjat set nimi=:nimi,tekija=:tekija,kuvaus=:kuvaus,hinta=:hinta,poistamispvm=:poistamispvm,kuva=:fileToUpload,lisayspvm=:lisayspvm,opiskelijaid=:opiskelijaid WHERE kirjaid=:kirjaid";
	$kysely = $yhteys->prepare($sql);
	$kysely->execute(array(":nimi"=>$nimi,":tekija"=>$tekija,":kuvaus"=>$kuvaus,":hinta"=>$hinta,":poistamispvm"=>$poistamispvm,":fileToUpload"=>$fileToUpload,"lisayspvm"=>$lisayspvm,":opiskelijaid"=>$opiskelijaid,":kirjaid"=>$kirjaid));
}
else {
	$sql = "UPDATE kirjat set nimi=:nimi,tekija=:tekija,kuvaus=:kuvaus,hinta=:hinta,poistamispvm=:poistamispvm,lisayspvm=:lisayspvm,opiskelijaid=:opiskelijaid WHERE kirjaid=:kirjaid";
	$kysely = $yhteys->prepare($sql);
	$kysely->execute(array(":nimi"=>$nimi,":tekija"=>$tekija,":kuvaus"=>$kuvaus,":hinta"=>$hinta,":poistamispvm"=>$poistamispvm,"lisayspvm"=>$lisayspvm,":opiskelijaid"=>$opiskelijaid,":kirjaid"=>$kirjaid));
}

if($kysely) 
{
	echo "<div class=\"alert alert-success\">Tiedot muutettu!</div><br>";
	echo "<a href=\"admin.php\">Palaa juttuluetteloon.</a><br>";
}

}
else

/********************************************************************
Jos tietoja puuttuu tai tullaan ensimmäistä kertaa sovellukseen,
tulostetaan lomake (valmiit tiedot lomakkeeseen). Jos tietoja puuttuu
tulostetaan niistä ilmoitus
********************************************************************/
{

echo "Täytä lomake kokonaan, pakolliset kentät on merkitty tähdellä.";
if(!empty($_POST)) 
{

if (empty($_POST['nimi'])) echo "Kirjoita nimi";	
if (empty($_POST['hinta'])) echo "Aseta hinta";

}

else
{

$sql="SELECT * FROM kirjat WHERE kirjaid=?";
$kysely = $yhteys->prepare($sql);
$kysely->execute(array($kirjaid));

$rivi = $kysely->fetchAll(PDO::FETCH_ASSOC);
if(!$rivi) echo "Juttua ei löydy ";
else
{

$kirjaid=$rivi[0]["kirjaid"];
$lisayspvm=$rivi[0]["lisayspvm"];
$poistamispvm=$rivi[0]["poistamispvm"];
$nimi=$rivi[0]["nimi"];
$tekija=$rivi[0]["tekija"];
$hinta=$rivi[0]["hinta"];
$kuvaus=$rivi[0]["kuvaus"];
$opiskelijaid=$rivi[0]["opiskelijaid"];
$kuva=$rivi[0]["kuva"];

}

}
?>
<div>
	<form action="./admin.php?sivu=muokkaa_kirjaa&mode=muokkaa&kirjaid=<?php echo $kirjaid;?>" method="post" enctype="multipart/form-data">
    <label for="fname">Nimi *</label>
    <input type="text" name="nimi" maxlength="50" value="<?php if(isset($nimi)) echo $nimi?>">

    <label for="lname">Tekijä *</label>
    <input type="text" name="tekija" maxlength="25" value="<?php if(isset($tekija)) echo $tekija?>">
	
	<label for="lname">Hinta *</label>
    <input type="text" name="hinta" value="<?php if(isset($hinta)) echo $hinta?>">
	
	<label for="lname">Kuvaus *</label>
    <textarea name="kuvaus" maxlength="1500"><?php if(isset($kuvaus)) echo $kuvaus?></textarea>
	
	<label for="lname">Poistamispäivämäärä (jos et aseta päiväystä, poistuu automaattisesti kahden viikon kuluttua)</label>
	<input type="date" id="pvm1" name="poistamispvm" value="<?php if(isset($poistamispvm)) echo $poistamispvm?>">
	
	<input type="hidden" name="kirjaid" value="<?php if(isset($kirjaid)) echo $kirjaid?>"> <br />
	
	<p><img src='sisalto/kuvat/<?php echo $kuva;?>' width='150' height='150' draggable='false' />
	
	<input type="file" name="fileToUpload" id="fileToUpload">
	<input type="submit" value="Muokkaa kirjaa" name="painike">
  </form>
</div>

<?php
}

}
?>