<?php
/* Tiedosto hakee vanhat käyttäjän tiedot lomakkeelle ja submit-painikkeen painamisen jälkeen lähettää ne palvelimelle. Tietojen oikeellisuus tarkistetaan ja jos kaikki on kunnossa, päivitetään tietokantaan. * Jotta käyttäjän tietoja voi muuttaa, tarvitaan käyttäjäid, jonka saa istunnosta. 
Taulun kentät
* kid int(6) auto_increment (on siis autonumber tai laskuri-tyyppinen)
* sukunimi varchar(30)
* etunimi varchar(30)
* ktunnus varchar(30)
* salasana varchar(100)
*/
require "./tietokanta/yhteys.php";
$opiskelijaid=$_SESSION["opiskelijaid"];//hakee kirjautumisen kohdalla luodusta istuntomuuttujasta kirjautuneen käyttäjän kid:n


if(isset($_GET["mode"])) $mode=$_GET["mode"];
else $mode="muokkaa";

/*********************************************************************/
$istuntosalasana=$_SESSION["salasana"];//otetaan muuttujaan salasana, joka käyttäjällä on kirjautuessa
$tiedotok=false;

if(isset($_POST["etunimi"]) && isset($_POST["sukunimi"]) && isset($_POST["sposti"]) && isset($_POST["vanhasalasana"]) )
{
	//otetaan lähetetyt tiedot muuttujiin
	$etunimi=putsaa($_POST["etunimi"]);
	$sukunimi=putsaa($_POST["sukunimi"]);

	echo "<script>alert('" . $etunimi . " " . $sukunimi . "')</script>";

	$tiedotok=true;

	//haetaan uudet salasanat ja tarkistetaan, että ne ovat samat. Jos ovat samat, otetaan uusi salasana muuttujaan $salasana
	if(!empty($_POST["salasana"]) && !empty($_POST["tokasalasana"]))
	{
		if(putsaa($_POST["salasana"]) == putsaa($_POST["tokasalasana"])) 
		{
			$salasana=muunna_salasana($_POST["salasana"]);
		}
		// jos eivät ole samat, mitään muutoksia ei tehdä
		else 
		{
			$tiedotok=FALSE;
			echo "Uudet salasanat eivät vastaa toisiaan, muutoksia ei tehdä!<br>";
		}
	}
	//jos ei annettu, salasana napataan istunnosta eli vanha salasana jää voimaan
	else 
	{
		$salasana = $istuntosalasana;
	}

	// salasanasuojataan lomakkeella annettu vanha salasana
	$vanhasalasana=muunna_salasana($_POST["vanhasalasana"]);

	//jos annettu vanha ei vastaa istunnossa olevaa salasanaa, muutosta ei tehdä

	if($istuntosalasana!=$vanhasalasana) 
	{
		$tiedotok=FALSE;
		echo "Anna alkuperäinen salasana oikein!<br>";
	}

	if($tiedotok==true) 
	{
		//rakennetaan sql-lause
		$sql="UPDATE opiskelijat SET etunimi=:etunimi,sukunimi=:sukunimi,salasana=:salasana WHERE opiskelijaid=:opiskelijaid;";
		$kysely=$yhteys->prepare($sql);
		$kysely->execute(array(":etunimi"=>$etunimi,":sukunimi"=>$sukunimi,":salasana"=>$salasana,":opiskelijaid"=>$opiskelijaid));

		if($kysely) 
		{
			echo "Tiedot muutettu";
			$tiedotok=true;
			$_SESSION["salasana"]=$salasana; //vaihdetaan istunnon salasanaa
		}

	}

} 

//jos tietoja puuttuu tai ei ole lähetetty lomaketta, haetaan olemassaolevat tiedot kannasta
if($tiedotok==false)
{

	$sql="SELECT * FROM opiskelijat WHERE opiskelijaid='$opiskelijaid'";//huom, tieto istunnosta, ei vaarallinen
	$kysely=$yhteys->query($sql);
	if(!$kysely) 
		echo "Käyttäjää ei löydy.";
	else //arvot kannasta muuttujiin 
	{

		$rivi = $kysely->fetchAll(PDO::FETCH_ASSOC); $etunimi=$rivi[0]["etunimi"];
		$sukunimi=$rivi[0]["sukunimi"];
		$sposti=$rivi[0]["sposti"];
		$salasana=$rivi[0]["salasana"];

	}
?>
<div>
<form action="admin.php?sivu=muokkaa_omia_tietoja&mode=muokkaa&opiskelijaid=<?php echo $opiskelijaid;?>" method="POST">
	<label for="sposti">Käyttäjätunnus *</label>
	<input type="text" name="sposti" readonly="true" value="<?php if(isset($sposti)) echo $sposti;?>"><br>
    <label for="etunimi">Etunimi *</label>
    <input type="text" name="etunimi" value="<?php if(isset($etunimi)) echo $etunimi;?>">

    <label for="sukunimi">Sukunimi *</label>
    <input type="text" name="sukunimi" value="<?php if(isset($sukunimi)) echo $sukunimi;?>">
	
	<label for="salasana">Uusi salasana</label>
    <input type="password" name="salasana">
	
	<label for="tokasalasana">Toista salasana</label>
    <input type="password" name="tokasalasana">
	
	<label for="lname">Nykyinen salasana (pakollinen kaikissa muutoksissa)</label>
	<input type="password" name="vanhasalasana">
	
	<input type="submit" value="Muuta tiedot">
</form>
</div>

<?php
}
?>