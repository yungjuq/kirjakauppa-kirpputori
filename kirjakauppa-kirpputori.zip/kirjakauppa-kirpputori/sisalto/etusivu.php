<!DOCTYPE html>
<html>
<head>
	<title>Kirjakauppa: Etusivu</title>
</head>
<body>
<div class="alert alert-warning" role="alert" style="width:84.5%;">
  <strong>Ilmoitus!</strong> Sivusto on vielä keskeneräinen, joten jotain bugeja saattaa olla.
</div>
<form action="index.php?sivu=index" method="POST">
<h4>Hae tiettyä kirjaa</h4>
<label for="search"></label>
<input type="text" name="haku" maxlength="100" placeholder="Kirjoita kenttään kirjan nimi" style="width:80%; border-radius: 0px;" />
<button type="submit" class="btn btn-primary btn-sm" style="border-radius: 0px;">Hae kirja</button>
</form>
<?php
$nyt=time();
$sql="SELECT * FROM kirjat ORDER BY lisayspvm desc";

if (isset($_POST["haku"])) {
	// hakukentästä löytyi tekstiä
	$haku = $_POST["haku"];
	echo "<p style=\"text-align: center\">Haettu " . $haku . "</p>";
	echo "<hr class=\"haku\">";
	$sql="SELECT * FROM kirjat WHERE nimi LIKE '%" . $haku . "%' ORDER BY lisayspvm desc";
}
else {
	echo "<p style=\"text-align: center\"></p>";	
	echo "<hr class=\"haku\">";
}


require "./tietokanta/yhteys.php";
$kysely=$yhteys->query($sql);

$rivit = $kysely->rowCount();
$vastaus = $kysely->fetchAll(PDO::FETCH_ASSOC); 
if($rivit<=100) $raja=$rivit;
else $raja=100;
for($i=0;$i<$raja;$i++)
{

$jid=$vastaus[$i]["kirjaid"];
$lisayspvm=$vastaus[$i]["lisayspvm"];
$nimi=$vastaus[$i]["nimi"];
$hinta=$vastaus[$i]["hinta"];
$kuva=$vastaus[$i]["kuva"];
$kuvaus=$vastaus[$i]["kuvaus"];
$kid=$vastaus[$i]["opiskelijaid"];
$kirjoittaja=kayttajan_nimi($kid,$yhteys);


echo "<div class=\"row\">";
    echo"<div class=\"col-md-4\">";
      echo "<div class=\"thumbnail\">";
			echo "<h4 style=\"text-align: center;\"><a href=\"./index.php?sivu=kirja&jid=$jid\">".$nimi."</a> <span class=\"badge badge-default\">".$hinta."€</span></h4>";
			echo "<p style=\"text-align: center;\">Lisätty ".$lisayspvm." </p>\n";
			echo "<img src='sisalto/kuvat/".$kuva."' width='150' height='150'/>";
			echo "<div class=\"caption\">";
            echo "<article style=\"text-align: center;\">".substr($kuvaus,0,100);
			echo "... <a href=\"./index.php?sivu=kirja&jid=$jid\">Lue lisää</a></article>\n";
          echo "</div>";
        echo "</a>";
      echo "</div>";
    echo "</div>";
	echo "</div>";
}
?>
  
  
  
  
  
  
 