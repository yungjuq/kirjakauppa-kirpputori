<!DOCTYPE html>
<html>
<head>
	<title>Kirpputori: Rekisteröidy</title>
</head>
<body>
<?php
error_reporting(0);
require_once "./kirjastot/funktiot.php";
require_once "./tietokanta/tkfunktiot.php";
$ok=false;
if(!empty($_POST['sukunimi']) && !empty($_POST['etunimi']) && !empty($_POST['ktunnus']) && !empty($_POST['salasana1']) && !empty($_POST['salasana1'])) {

$ok=TRUE;
$etunimi=$_POST['etunimi'];
$sukunimi= $_POST['sukunimi'];
$ktunnus=$_POST['ktunnus'];
require "./tietokanta/yhteys.php";
if($_POST['salasana1'] != $_POST['salasana2'] || tunnusta_ei_kannassa($yhteys,$ktunnus)== FALSE) $ok=FALSE;
else
{

$etunimi=putsaa($etunimi);
$sukunimi=putsaa($sukunimi);
$ktunnus=putsaa($ktunnus);

$salasana=$_POST['salasana1'];
$salasana = muunna_salasana($salasana);//suojataan salasana

$sql="INSERT INTO opiskelijat (etunimi,sukunimi,sposti,salasana) VALUES (?,?,?,?)";
$kysely = $yhteys->prepare($sql);
$kysely->execute(array($etunimi,$sukunimi,$ktunnus,$salasana));
if($kysely!=FALSE) echo "Käyttajä on lisätty!
";

}

}
if(!$_POST || $ok==FALSE)
{

if(!empty($_POST))
{

if(empty($_POST['etunimi'])) echo "Etunimi puuttuu, ";
if(empty($_POST['sukunimi'])) echo "Sukunimi puuttuu, ";
if(empty($_POST['ktunnus'])) echo "Sähköpostiosoite puuttuu,  ";
if(empty($_POST['salasana1'])) echo "Toinen salasanoista puuttuu, ";
if(empty($_POST['salasana2'])) echo "Toinen salasanoista puuttuu, ";
if(!empty($_POST['salasana1']) && !empty($_POST['salasana2'])) {

if($_POST['salasana1'] != ($_POST['salasana2']) ) echo "<div class=\"alert alert-danger\" style=\"text-align: center;\">Salasanat eivät vastaa toisiaan</div>";

}
if(tunnusta_ei_kannassa($yhteys,$ktunnus)==TRUE) echo "<div class=\"alert alert-danger\" style=\"text-align: center;\">Sähköpostiosoite on jo käytössä, kokeile toista tunnusta.</div>";

}

?>
<h3 style="text-align: center;">Rekisteröidy</h3>
<div>
<form method="post" action = "index.php?sivu=rekisteroidy">
    <label for="etunimi"></label>
    <input type="text" name="etunimi" placeholder="Etunimi" value="<?php if(isset($_POST['etunimi'])) echo $_POST['etunimi']?>">

    <label for="sukunimi"></label>
    <input type="text" name="sukunimi" placeholder="Sukunimi" value="<?php if(isset($_POST["sukunimi"])) echo $_POST['sukunimi']?>">
	
	<label for="sähköposti"></label>
    <input type="text" name="ktunnus" placeholder="Sähköpostiosoite" value="<?php if(isset($_POST['ktunnus'])) echo $_POST['ktunnus']?>">
	
	<label for="salasana1"></label>
    <input type="password" name="salasana1" placeholder="Salasana" value="<?php if(isset($_POST['salasana1'])) echo $_POST['salasana1']?>"
	
	<label for="salasana2"></label>
	<input type="password" name="salasana2" placeholder="Toista salasana" value="<?php if(isset($_POST['salasana2'])) echo $_POST['salasana2']?>">
	
	<input type="submit" value="Rekisteröidy">
</form>
</div>
<?php
}
?>