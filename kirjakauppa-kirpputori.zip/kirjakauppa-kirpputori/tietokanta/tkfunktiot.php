<?php

function muunna_salasana($sana)
{

$sana.="JO0blEp+nEl5nNhgUqoZRJNecogM1XHIXUCatPOJycs";
$sana=md5($sana);
return $sana;

}

function tunnusta_ei_kannassa($yhteys,$ktunnus)
{
$kysely = $yhteys->prepare("SELECT * FROM opiskelijat WHERE sposti=?");
$kysely->execute(array($ktunnus)); $rivimaara = $kysely->rowCount(); 

if($rivimaara == 0) return true;
else return false;

}

function hae_id_kannasta($yhteys,$ktunnus,$salasana)
{
$id=NULL;
$lause = $yhteys->prepare("SELECT * FROM opiskelijat WHERE sposti=:ktunnus AND salasana =:salasana");
$lause->bindParam(':ktunnus', $ktunnus);
$lause->bindParam(':salasana', $salasana);

$tunnari = $ktunnus;
$passu = $salasana;

$lause->execute();

$rivi = $lause->fetchAll(PDO::FETCH_ASSOC);
if(!empty($rivi)) $id = $rivi[0]["opiskelijaid"];
return $id;

}

function kayttajan_nimi($kid,$yhteys)
{

$sql="SELECT etunimi,sukunimi FROM opiskelijat WHERE opiskelijaid=?";

$teksti="";

$kysely=$yhteys->prepare($sql);
$kysely->execute(array($kid));

$rivi=$kysely->fetchAll(PDO::FETCH_ASSOC);
if(empty($rivi)) $teksti= "K�ytt�j�� ei l�ydy.";
else
{

$etunimi=$rivi[0]["etunimi"];
$sukunimi=$rivi[0]["sukunimi"];
$teksti.= $etunimi." ".$sukunimi;

}
return $teksti;

}
