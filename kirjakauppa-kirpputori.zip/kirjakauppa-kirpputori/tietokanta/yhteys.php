<?php
$tietokantayhteys = "localhost";
$kayttaja = "root";
$passu = " ";
$skeema = " ";

try
{
	$yhteys = new PDO("mysql:host=$tietokantayhteys;dbname=$skeema;charset=utf8",$kayttaja,$passu);
}
catch(PDOException $e)
{
	echo $e->getMessage();
}
?>