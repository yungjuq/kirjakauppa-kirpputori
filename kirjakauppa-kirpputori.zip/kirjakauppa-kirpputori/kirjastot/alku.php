<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/main.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script src="./js/datetimepicker.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet"> 
</head>
<body>
<div class="ylapalkki">
<h1 style="margin-left: 11%; font-family: 'Oswald', sans-serif;">KIRJAKAUPPA</h1>
<div class="btn-group" id="navi" style="margin-left: 9.5%;">
  <button class="button" onclick="window.location.href='index.php?sivu=index'">Etusivu</button>
  <button class="button" onclick="window.location.href='index.php?sivu=tietoa'">Tietoa yrityksestä</button>
  <button class="button" onclick="window.location.href='index.php?sivu=otayhteytta'">Ota yhteyttä</button>
  <button class="button" onclick="window.location.href='index.php?sivu=kirjaudu'">Kirjaudu</button>
  <button class="button" onclick="window.location.href='index.php?sivu=rekisteroidy'">Rekisteröidy</button>
</div>

	<!--- <div class="btn-group">
	<a href="index.php?sivu=index" class="btn btn-success">Etusivu</a>
	<a href="index.php?sivu=otayhteytta" class="btn btn-success">Ota yhteyttä</a>
	<a href="index.php?sivu=kirjaudu" class="btn btn-success">Kirjaudu</a>
	<a href="index.php?sivu=rekisteroidy" class="btn btn-success">Rekisteröidy</a>
	</li>
	</div> --->
</div>
<div id="uutiset">