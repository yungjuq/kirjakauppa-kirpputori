<!DOCTYPE html>
<html>
<head>
	<title>KIRJAKAUPPA: Ylläpito</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" href="./css/main.css">
	<script src="./js/datetimepicker.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet"> 
<body>

<div class="ylapalkki">
<h1 style="margin-left: 11%; font-family: 'Oswald', sans-serif;">KIRJAKAUPPA</h1>
<div class="btn-group" style="margin-left: 9.5%;">
  <button class="button" onclick="window.location.href='admin.php?sivu=admin'">Etusivu</button>
  <button class="button" onclick="window.location.href='admin.php?sivu=lisaa_kirja'">Lisää kirja</button>
  <button class="button" onclick="window.location.href='admin.php?sivu=muokkaa_omia_tietoja'">Muokkaa omia tietoja</button>
  <button class="button" onclick="window.location.href='kirjaudu_ulos.php'">Kirjaudu ulos</button>
</div>
</div>


<div id="keskiosa" style="text-align:center;">
<div id="teksti">